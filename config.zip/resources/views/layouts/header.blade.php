<!-- Start Header Top Area -->
<div class="header-top-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="logo-area">
                    <a href="#">
                        <img src="{{url('/theme/img/logo/logo.png')}}" alt="" />
                    </a>
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <div class="header-top-menu">
                    <ul class="nav navbar-nav notika-top-nav">                           
                        <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><span><i class="notika-icon notika-menus"></i></span></a>
                            <div role="menu" class="dropdown-menu message-dd chat-dd animated zoomIn">
                                <div class="hd-mg-tt">
                                    <h2>Profile</h2>
                                </div>                                
                                <div class="hd-message-info">
                                    <a href="{{route('changePasswordForm')}}">
                                        <div class="hd-message-sn">
                                            <div class="hd-message-img chat-img">                                                
                                                <i class="notika-icon notika-refresh"></i>
                                            </div>
                                            <div class="hd-mg-ctn">
                                                <h3>Ganti Password</h3>                                                
                                            </div>
                                        </div>
                                    </a>
                                    <a href="{{route('logout')}}">
                                        <div class="hd-message-sn">
                                            <div class="hd-message-img chat-img">
                                                <i class="notika-icon notika-left-arrow"></i>
                                            </div>
                                            <div class="hd-mg-ctn">
                                                <h3>Logout</h3>                                                
                                            </div>
                                        </div>
                                    </a>                                   
                                </div>                              
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Header Top Area -->
<!-- Mobile Menu start -->
<div class="mobile-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="mobile-menu">
                    <nav id="dropdown">
                        <ul class="mobile-menu-nav">
                            <li>
                                <a href="{{route('home')}}">Home</a>                               
                            </li>
                            @if(auth()->user()->is_admin == '1')
                                <li>
                                    <a href="{{route('diklat.all')}}">Diklat</a>                               
                                </li>
                                <li>
                                    <a href="{{route('materi.all')}}">Materi</a>                                
                                </li>
                                <li>
                                    <a href="{{route('peserta.all')}}">Claon Peserta</a>                                
                                </li>                            
                            @endif
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Mobile Menu end -->
<!-- Main Menu area start-->
<div class="main-menu-area mg-tb-40">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                    @if(auth()->user()->is_admin == '1')
                        <li>
                            <a href="{{route('home')}}"><i class="notika-icon notika-house"></i> Home</a>
                        </li>
                        <li>
                            <a href="{{route('diklat.all')}}"><i class="notika-icon notika-mail"></i> Diklat</a>
                        </li>
                        <li>
                            <a href="{{route('materi.all')}}"><i class="notika-icon notika-support"></i> Materi</a>
                        </li>
                        <li>
                            <a href="{{route('peserta.all')}}"><i class="notika-icon notika-support"></i> Peserta</a>
                        </li>
                        <li>
                            <a href="{{route('peserta.unverified')}}"><i class="notika-icon notika-support"></i> Calon Peserta</a>
                        </li>
                    @else
                        <li>
                            <a href="{{route('peserta.profile')}}"><i class="notika-icon notika-support"></i> Profil</a>
                        </li>
                        <li>
                            <a href="{{route('peserta.dataDiri')}}">
                                <i class="notika-icon notika-checked"></i> 
                                Data Diri</a>
                        </li>
                        <li>
                            <a href="{{route('peserta.riwayatPendidikan')}}">
                                <i class="notika-icon notika-checked"></i> 
                                Riwayat Pendidikan</a>
                        </li>
                        <li>
                            <a href="{{route('peserta.pengalamanKerja')}}">
                                <i class="notika-icon notika-close"></i> 
                                Pengalaman Kerja</a>
                        </li>
                        <li>
                            <a href="{{route('peserta.pengalamanOrganisasi')}}">
                                <i class="notika-icon notika-close"></i> 
                                Pengalaman Organisasi</a>
                        </li>
                        <li>
                            <a href="{{route('home')}}">
                                <i class="notika-icon notika-house"></i> 
                                Daftar Materi</a>
                        </li>
                    @endif
                </ul>                 
            </div>
        </div>
    </div>
</div>

@if(Route::current()->getName() != 'home')
<div class="breadcomb-area " style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-windows"></i>
                                </div>
                                <div class="breadcomb-ctn">  
                                    @if(isset($title))
                                        <h2>
                                            {{$title}} 
                                            @if(isset($verified) && $verified)
                                                &nbsp;&nbsp; <button class="btn btn-success">Verified</button>
                                            @endif
                                            @if(isset($verified) && !$verified)
                                                &nbsp;&nbsp; <button class="btn btn-danger">Unverified</button>
                                            @endif
                                        </h3>                                        
                                    @else
                                        <h2>Data Diklat</h2>     
                                    @endif
                                    @if(isset($breadcrumb))
                                        <p>{{$breadcrumb}}
                                    @else
                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                                    @endif
                                </div>
                            </div>
                        </div>
                        @if(isset($route))
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                <button data-toggle="tooltip" data-placement="top" title="Print" class="btn"><i class="notika-icon notika-sent"></i></button>
                                <a href="{{$route}}" data-toggle="tooltip" data-placement="top" title="Tambah Data" class="btn"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif