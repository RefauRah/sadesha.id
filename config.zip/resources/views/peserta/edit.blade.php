@extends('layouts.app')
@section('content')
<div class="form-example-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <form action="{{route('peserta.dataDiriUpdate')}}" method="post">
            @csrf
            <div class="col-sm-12">
                <div class="form-example-wrap">
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Nama Peserta</label>
                            <div class="nk-int-st">
                                <input type="text" name="nama_peserta" class="form-control input-sm" value="{{$peserta != null ? $peserta->nama_peserta: ''}}" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Email</label>
                            <div class="nk-int-st">
                                <input type="text" name="email" class="form-control input-sm" value="{{$peserta != null ? $peserta->email: ''}}" required>
                            </div>
                        </div>
                    </div>
                    <div class="datepicker-int datepicker-restyle  mg-t-15">
                        <div class="form-group nk-datapk-ctm form-elet-mg" id="data_1">
                            <label>Tanggal Lahir</label>
                            <div class="input-group date nk-int-st">
                                <span class="input-group-addon"></span>
                                <input type="text" name="tgl_lahir" class="form-control" value="{{$peserta != null ? date('m/d/Y', strtotime($peserta->tgl_lahir)) : date('m/d/1995')}}" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Alamat</label>
                            <div class="nk-int-st">
                                <textarea name="alamat" class="form-control">{{$peserta != null ? $peserta->alamat : ''}}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>No. HP</label>
                            <div class="nk-int-st">
                                <input type="text" name="no_hp" class="form-control input-sm" value="{{$peserta != null ? $peserta->no_hp : ''}}" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int mg-t-15">
                        <div class="form-group">
                            <label>Agama</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select name="agama" class="selectpicker" required>
                                @if($peserta!=null)
                                    <option {{$peserta->agama == 'ISLAM' ? 'selected' : ''}} value="ISLAM">Islam</option>
                                    <option {{$peserta->agama == 'KRISTEN' ? 'selected' : ''}} value="KRISTEN">Kristen</option>
                                @else 
                                    <option value="ISLAM">Islam</option>
                                    <option value="KRISTEN">Kristen</option>
                                @endif
                                </select>
                            </div>
                        </div>
                    </div>  
                    <div class="form-example-int mg-t-15">
                        <div class="form-group">
                            <label>Status Peserta</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select name="status" class="selectpicker" required>
                                @if($peserta!=null)
                                    <option {{$peserta->status == 'MAHASISWA' ? 'selected' : ''}} value="MAHASISWA">MAHASISWA</option>
                                    <option {{$peserta->status == 'PELAJAR' ? 'selected' : ''}} value="PELAJAR">PELAJAR</option>
                                @else
                                    <option value="MAHASISWA">MAHASISWA</option>
                                    <option value="PELAJAR">PELAJAR</option>
                                @endif
                                </select>
                            </div>
                        </div>
                    </div>  
                    <input type="hidden" value="{{isset($peserta->id) ? '1' : '0'}}" name="is_edit">
                    <button type="submit" class="btn btn-success notika-btn-success">Submit</button>
                    <a href="{{url()->previous()}}" class="btn btn-danger notika-btn-success">Back</a>
                </div>
            </div>
            </form>
        </div>           
    </div>
</div> 

@endsection