@extends('layouts.app')
@section('content');
<div class="container">    
    <div class="row">
        <div class="col-lg-12">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Detail Profil</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Nomor Peserta</th>
                                <td>1</td>         
                            </tr>                              
                            <tr>
                                <th>Nama Lengkap</th>
                                <td>Alexandra</td>                    
                            </tr>
                            <tr>
                                <th>Tanggal Lahir</th>
                                <td>Madeleine</td>                       
                            </tr>

                            <tr>
                                <th>Agama</th>
                                <td>Madeleine</td>                       
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>Madeleine</td>                       
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td>Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                            </tr>
                            <tr>
                                <th>Nomor HP</th>
                                <td>Madeleine</td>                       
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td>Madeleine</td>                       
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Riwayat Pendidikan</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Tipe Pendidikan</th>
                                <td>1</td>         
                            </tr>                              
                            <tr>
                                <th>Nama Instansi</th>
                                <td>Alexandra</td>                    
                            </tr>
                            <tr>
                                <th>Tahun Masuk</th>
                                <td>Madeleine</td>                       
                            </tr>

                            <tr>
                                <th>Tahun Lulus</th>
                                <td>Madeleine</td>                       
                            </tr>                                                                         
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Pengalaman Organisasi</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Nama Organisasi</th>
                                <td>1</td>         
                            </tr>                              
                            <tr>
                                <th>Jabatan</th>
                                <td>Alexandra</td>                    
                            </tr>
                            <tr>
                                <th>Tahun</th>
                                <td>Madeleine</td>                       
                            </tr>                                                       
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Pengalaman Bekerja</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Nama Instansi</th>
                                <td>1</td>         
                            </tr>                              
                            <tr>
                                <th>Jabatan</th>
                                <td>Alexandra</td>                    
                            </tr>
                            <tr>
                                <th>Tanggal Mulai</th>
                                <td>Madeleine</td>                       
                            </tr> 
                            <tr>
                                <th>Tanggal Selesai</th>
                                <td>Madeleine</td>                       
                            </tr>                                                       
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>        
</div>
@endsection