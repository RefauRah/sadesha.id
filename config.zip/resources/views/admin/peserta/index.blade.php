@extends('layouts.app')
@section('content')
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">                  
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No Peserta</th>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th> 
                                    <th>Opsi</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($peserta as $res)
                                <tr>
                                    <td>Tiger Nixon</td>
                                    <td>System Architect</td>
                                    <td>Edinburgh</td>
                                    <td>61</td>
                                    <td>2011/04/25</td> 
                                    <td>Lorem ipsum, dolor sit amet</td> 
                                    <td>
                                        <div class="btn-group">
                                            <a href="{{route('peserta.edit',1)}}" class="btn btn-default btn-icon-notika" title="Edit"><i class="notika-icon notika-edit"></i></a>
                                            <a href="{{route('peserta.delete')}}" class="btn btn-default btn-icon-notika" title="Hapus" id="sa-warning"><i class="notika-icon notika-close"></i></a>                                            
                                            <a href="{{route('peserta.detail',1)}}" class="btn btn-default btn-icon-notika" title="Detail"><i class="notika-icon notika-tax"></i></a>                                            
                                        </div> 
                                    </td>                                  
                                </tr>       
                                @endforeach                                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>No Peserta</th>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th>
                                    <td>Opsi</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
