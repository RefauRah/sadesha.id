@extends('layouts.app')
@section('content');
<div class="container">   
    <div class="row">
        <div class="col-lg-12">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Materi</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Tema</th>
                                <td>1</td>         
                            </tr>                              
                            <tr>
                                <th>Nama Pemateri</th>
                                <td>Alexandra</td>                    
                            </tr>
                            <tr>
                                <th>Tanggal</th>
                                <td>Madeleine</td>                       
                            </tr>
                            <tr>
                                <th>Waktu Mulai</th>
                                <td>Madeleine</td>                       
                            </tr>
                            <tr>
                                <th>Waktu Selesai</th>
                                <td>Madeleine</td>                       
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>Madeleine</td>                       
                            </tr>                                         
                        </tbody>
                    </table>
                </div>
            </div>
        </div>       
    </div>        
</div>

<div class="breadcomb-area " style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-windows"></i>
                                </div>
                                <div class="breadcomb-ctn">                                                                   
                                    <h2>Data Peserta</h2>     
                                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                <button data-toggle="tooltip" data-placement="left" title="Download Report" class="btn"><i class="notika-icon notika-sent"></i></button>
                                <a href="{{url('/peserta/create')}}" data-toggle="tooltip" data-placement="left" title="Tambah Data" class="btn"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">                  
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No Peserta</th>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th> 
                                    <th>Opsi</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Tiger Nixon</td>
                                    <td>System Architect</td>
                                    <td>Edinburgh</td>
                                    <td>61</td>
                                    <td>2011/04/25</td> 
                                    <td>Lorem ipsum, dolor sit amet</td> 
                                    <td>
                                        <div class="btn-group">
                                            <a href="{{url('/peserta/edit')}}" class="btn btn-default btn-icon-notika" title="Edit"><i class="notika-icon notika-edit"></i></a>
                                            <a href="{{url('/peserta/delete')}}" class="btn btn-default btn-icon-notika" title="Hapus"><i class="notika-icon notika-close"></i></a>                                            
                                            <a href="{{url('/peserta/detail')}}" class="btn btn-default btn-icon-notika" title="Detail"><i class="notika-icon notika-tax"></i></a>                                            
                                            <a href="{{url('/peserta/absensi')}}" class="btn btn-default btn-icon-notika" title="Absensi"><i class="notika-icon notika-support"></i></a>                                            
                                        </div> 
                                    </td>                                  
                                </tr>                                                       
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>No Peserta</th>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th>
                                    <td>Opsi</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection