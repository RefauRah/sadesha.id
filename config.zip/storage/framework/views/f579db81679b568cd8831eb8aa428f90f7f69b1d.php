
<?php $__env->startSection('content'); ?>
<div class="form-example-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <form action="<?php echo e(route('peserta.pengalamanOrganisasi.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-sm-12">
                <div class="form-example-wrap">
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Nama Organisasi</label>
                            <div class="nk-int-st">
                                <input type="text" name="nama_organisasi" class="form-control input-sm" value="<?php echo e($organisasi->nama_organisasi); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Jabatan</label>
                            <div class="nk-int-st">
                                <input type="text" name="jabatan" class="form-control input-sm" value="<?php echo e($organisasi->jabatan); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Tahun</label>
                            <div class="nk-int-st">
                                <input type="text" name="tahun" class="form-control input-sm" placeholder="2005" value="<?php echo e($organisasi->tahun); ?>" required>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" value="<?php echo e($organisasi->id); ?>" name="id">
                    <button type="submit" class="btn btn-success notika-btn-success">Submit</button>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger notika-btn-success">Back</a>
                </div>
            </div>
            </form>
        </div>           
    </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/peserta/pengalaman_organisasi/edit.blade.php ENDPATH**/ ?>