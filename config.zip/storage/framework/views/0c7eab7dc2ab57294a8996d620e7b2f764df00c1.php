
<?php $__env->startSection('content'); ?>;
<div class="container">   
    <div style="background: #fff"> 
    <div class="row" style="padding-top:30px">
        <div class="col-sm-10 col-sm-offset-1">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Data Diri</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-no-bordered">
                        <tbody>
                            <tr>
                                <th>Nomor Peserta</th>
                                <td><?php echo e($peserta != null ? $peserta->no_peserta : '-'); ?></td>         
                            </tr>                              
                            <tr>
                                <th>Nama Lengkap</th>
                                <td><?php echo e($peserta != null ? $peserta->nama_peserta : '-'); ?></td>                    
                            </tr>
                            <tr>
                                <th>Tanggal Lahir</th>
                                <td><?php echo e($peserta != null ? $peserta->tgl_lahir : '-'); ?></td>                       
                            </tr>

                            <tr>
                                <th>Agama</th>
                                <td><?php echo e($peserta != null ? $peserta->agama : '-'); ?></td>                       
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($peserta != null ? $peserta->status : '-'); ?></td>                       
                            </tr>
                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($peserta != null ? $peserta->alamat : '-'); ?></td>
                            </tr>
                            <tr>
                                <th>Nomor HP</th>
                                <td><?php echo e($peserta != null ? $peserta->no_hp : '-'); ?></td>                       
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo e($peserta != null ? $peserta->email : '-'); ?></td>                       
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-sm-10 col-sm-offset-1">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Riwayat Pendidikan</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-no-bordered">
                        <thead>
                            <tr>
                                <th>Nama Instansi</th>
                                <th>Tahun Masuk</th>
                                <th>Tahun Lulus</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($pendidikan) > 0): ?>
                                <?php $__currentLoopData = $pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pddkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pddkn->nama_instansi); ?></td>
                                        <td><?php echo e($pddkn->tahun_masuk); ?></td>
                                        <td><?php echo e($pddkn->tahun_lulus); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php else: ?>
                                <tr>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            <?php endif; ?>                                                                
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-sm-10 col-sm-offset-1">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Pengalaman Organisasi</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-no-bordered">
                        <thead>
                            <tr>
                                <th>Nama Organisasi</th>
                                <th>Jabatan</th>
                                <th>Tahun</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($organisasi) > 0): ?>
                                <?php $__currentLoopData = $organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($org->nama_organisasi); ?></td>
                                        <td><?php echo e($org->jabatan); ?></td>
                                        <td><?php echo e($org->tahun); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php else: ?>
                                <tr>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            <?php endif; ?>                                    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-sm-10 col-sm-offset-1">
            <div class="normal-table-list" style="margin-top:-20px">
                <div class="basic-tb-hd">
                    <h2>Pengalaman Bekerja</h2>            
                </div>
                <div class="bsc-tbl-bdr">
                    <table class="table table-no-bordered">
                        <thead>
                            <tr>
                                <th>Nama Instansi</th>
                                <th>Jabatan</th>
                                <th>Tanggal Mulai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($kerja) > 0): ?>
                                <?php $__currentLoopData = $kerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($krj->nama_instansi); ?></td>
                                        <td><?php echo e($krj->jabatan); ?></td>
                                        <td><?php echo e($krj->tgl_mulai); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php else: ?>
                                <tr>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            <?php endif; ?>                                    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/peserta/profile.blade.php ENDPATH**/ ?>