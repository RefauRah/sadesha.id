
<?php $__env->startSection('content'); ?>
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">                  
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>                                    
                                    <th>Nama Organisasi</th>
                                    <th>Jabatan</th>
                                    <th>Tahun</th>                                 
                                    <th>Opsi</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pengalaman_organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                   
                                <tr>
                                    <td><?php echo e($organisasi->nama_organisasi); ?></td>
                                    <td><?php echo e($organisasi->jabatan); ?></td>
                                    <td><?php echo e($organisasi->tahun); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('peserta.pengalamanOrganisasi.edit',$organisasi->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                 
                            </tbody>
                            <tfoot>
                                <tr>                                    
                                    <th>Nama Organisasi</th>
                                    <th>Jabatan</th>
                                    <th>Tahun</th>                                 
                                    <th>Opsi</th> 
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/peserta/pengalaman_organisasi/index.blade.php ENDPATH**/ ?>