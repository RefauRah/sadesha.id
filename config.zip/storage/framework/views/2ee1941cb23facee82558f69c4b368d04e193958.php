
<?php $__env->startSection('content'); ?>
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
            </div>
            <div class="col-sm-12">
                <div class="data-table-list">  
                    <div class="table-responsive">
                        <table id="tabel-materi" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Tema Materi</th>
                                    <th>Pemateri</th>
                                    <th>Tanggal</th>
                                    <th>Waktu Mulai</th>
                                    <th>Waktu Selesai</th>
                                    <th>Status</th>         
                                    <th>Opsi</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>       
                                    <td><?php echo e($res->tema_materi); ?></td>
                                    <td><?php echo e($res->nama_pemateri); ?></td>
                                    <td><?php echo e($res->tanggal); ?></td>
                                    <td><?php echo e($res->waktu_mulai); ?></td>
                                    <td><?php echo e($res->waktu_selesai); ?></td>
                                    <td>
                                        <button class="btn btn-sm <?php echo e($res->status == '0' ? 'btn-success' : 'btn-danger'); ?>">
                                            <?php echo e($res->status == '0' ? 'BELUM SELESAI' : 'SELESAI'); ?>

                                        </button>
                                    </td>
                                    <td>
                                     <div class="btn-group">
                                        <form action="<?php echo e(route('materi.delete')); ?>" method="post">
                                            <a href="<?php echo e(route('materi.edit',$res->id)); ?>" class="btn btn-default btn-icon-notika" title="Edit">
                                                <i class="notika-icon notika-edit"></i>
                                            </a> 
                                            <?php echo csrf_field(); ?>
                                            <?php if($res->status!='1'): ?>
                                                <input type="hidden" value="<?php echo e($res->id); ?>" name="id">
                                                <?php if(isset($_GET['id_diklat'])): ?>
                                                <input type="hidden" value="<?php echo e($_GET['id_diklat']); ?>" name="id_diklat">
                                                <?php endif; ?>
                                                <button type="submit" onclick="return confirm('Anda yakin?')" 
                                                    class="btn btn-default btn-icon-notika">
                                                    <i class="notika-icon notika-close"></i>
                                                </button>
                                            <?php endif; ?>
                                            <?php if(!isset($_GET['id_diklat'])): ?>
                                            <a href="<?php echo e(route('materi.edit',$res->id)); ?>" class="btn btn-default btn-icon-notika" title="Detail">
                                                <i class="notika-icon notika-next"></i>
                                            </a>
                                            <?php endif; ?>
                                        </form>
                                    </div>  
                                    </td>
                                </tr>                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                   
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Tema Materi</th>
                                    <th>Pemateri</th>
                                    <th>Tanggal</th>
                                    <th>Waktu Mulai</th>
                                    <th>Waktu Selesai</th>
                                    <th>Status</th>         
                                    <th>Opsi</th>                                    
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('#tabel-materi').DataTable( {
            "order": [[ 5, "asc" ]]
        } );
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/admin/materi/index.blade.php ENDPATH**/ ?>