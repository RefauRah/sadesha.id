
<?php $__env->startSection('content'); ?>
<div class="form-example-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <form action="<?php echo e(route('peserta.riwayatPendidikan.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-sm-12">
                <div class="form-example-wrap">
                    <div class="form-example-int mg-t-15">
                        <div class="form-group">
                            <label>Tipe Pendidikan</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select name="id_tipe_pendidikan" class="selectpicker" required>
                                    <?php $__currentLoopData = $tipe_pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tipe->id); ?>" <?php echo e($pendidikan->id_tipe_pendidikan == $tipe->id ? 'selected': ''); ?>>
                                            <?php echo e($tipe->nama_tipe); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div> 
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Nama Instansi</label>
                            <div class="nk-int-st">
                                <input type="text" name="nama_instansi" class="form-control input-sm" value="<?php echo e($pendidikan->nama_instansi); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Tahun Masuk</label>
                            <div class="nk-int-st">
                                <input type="text" name="tahun_masuk" class="form-control input-sm" placeholder="2005" value="<?php echo e($pendidikan->tahun_masuk); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Tahun Lulus</label>
                            <div class="nk-int-st">
                                <input type="text" name="tahun_lulus" class="form-control input-sm" placeholder="2009" value="<?php echo e($pendidikan->tahun_lulus); ?>" required>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" value="<?php echo e($pendidikan->id); ?>" name="id">
                    <button type="submit" class="btn btn-success notika-btn-success">Submit</button>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger notika-btn-success">Back</a>
                </div>
            </div>
            </form>
        </div>           
    </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/peserta/riwayat_pendidikan/edit.blade.php ENDPATH**/ ?>