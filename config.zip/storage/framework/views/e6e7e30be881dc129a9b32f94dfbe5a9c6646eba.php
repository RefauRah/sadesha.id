
<?php $__env->startSection('content'); ?>
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">                  
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nama Instansi</th>
                                    <th>Tahun Masuk</th>
                                    <th>Tahun Lulus</th>                                    
                                    <th>Opsi</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $riwayat_pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendidikan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pendidikan->nama_instansi); ?></td>
                                    <td><?php echo e($pendidikan->tahun_masuk); ?></td>
                                    <td><?php echo e($pendidikan->tahun_lulus); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('peserta.riwayatPendidikan.edit',$pendidikan->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                    </td>
                                </tr>                                       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Nama Instansi</th>
                                    <th>Tahun Masuk</th>
                                    <th>Tahun Lulus</th>                                    
                                    <th>Opsi</th>       
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/peserta/riwayat_pendidikan/index.blade.php ENDPATH**/ ?>