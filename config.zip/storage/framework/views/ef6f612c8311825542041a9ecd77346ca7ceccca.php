
<?php $__env->startSection('content'); ?>
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">                  
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No Peserta</th>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th> 
                                    <th>Opsi</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>Tiger Nixon</td>
                                    <td>System Architect</td>
                                    <td>Edinburgh</td>
                                    <td>61</td>
                                    <td>2011/04/25</td> 
                                    <td>Lorem ipsum, dolor sit amet</td> 
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('peserta.edit',1)); ?>" class="btn btn-default btn-icon-notika" title="Edit"><i class="notika-icon notika-edit"></i></a>
                                            <a href="<?php echo e(route('peserta.delete')); ?>" class="btn btn-default btn-icon-notika" title="Hapus" id="sa-warning"><i class="notika-icon notika-close"></i></a>                                            
                                            <a href="<?php echo e(route('peserta.detail',1)); ?>" class="btn btn-default btn-icon-notika" title="Detail"><i class="notika-icon notika-tax"></i></a>                                            
                                        </div> 
                                    </td>                                  
                                </tr>       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>No Peserta</th>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Alamat</th>
                                    <th>Email</th>
                                    <th>No HP</th>
                                    <td>Opsi</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/admin/peserta/index.blade.php ENDPATH**/ ?>