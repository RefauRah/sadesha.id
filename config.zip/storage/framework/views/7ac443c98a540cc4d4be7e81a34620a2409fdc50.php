
<?php $__env->startSection('content'); ?>
<div class="notika-status-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30">
                    <div class="website-traffic-ctn">
                        <h2><span class="counter">50,000</span></h2>
                        <p>Total Website Traffics</p>
                    </div>
                    <div class="sparkline-bar-stats1">9,4,8,6,5,6,4,8,3,5,9,5</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30">
                    <div class="website-traffic-ctn">
                        <h2><span class="counter">90,000</span>k</h2>
                        <p>Website Impressions</p>
                    </div>
                    <div class="sparkline-bar-stats2">1,4,8,3,5,6,4,8,3,3,9,5</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 dk-res-mg-t-30">
                    <div class="website-traffic-ctn">
                        <h2>$<span class="counter">40,000</span></h2>
                        <p>Total Online Sales</p>
                    </div>
                    <div class="sparkline-bar-stats3">4,2,8,2,5,6,3,8,3,5,9,5</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 dk-res-mg-t-30">
                    <div class="website-traffic-ctn">
                        <h2><span class="counter">1,000</span></h2>
                        <p>Total Support Tickets</p>
                    </div>
                    <div class="sparkline-bar-stats4">2,4,8,4,5,7,4,7,3,5,7,5</div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="data-table-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">                  
                    <div class="table-responsive">
                        <table id="tabel-diklat" class="table table-striped table-diklat">
                            <thead>
                                <tr>
                                    <th>Nama Diklat</th>
                                    <th>Kota</th>
                                    <th>Mulai</th>
                                    <th>Selesai</th>
                                    <th>Status</th>
                                    <th>Opsi</th>                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $diklat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php echo e($res->status=='1'?'row-active':''); ?>">       
                                    <td><?php echo e($res->nama_diklat); ?></td>
                                    <td><?php echo e($res->kota->nama_kota); ?></td>
                                    <td><?php echo e($res->tgl_mulai); ?></td>
                                    <td><?php echo e($res->tgl_selesai); ?></td>
                                    <td>
                                        <button class="btn btn-sm <?php echo e($res->status == '1' ? 'btn-success' : ($res->status == '2' ? 'btn-warning' : 'btn-danger')); ?>">
                                            <?php echo e($res->status == '1' ? 'DIBUKA' : ($res->status == '2' ? 'DITUTUP' : 'SELESAI')); ?>

                                        </button>
                                    </td>
                                    <td>
                                     <div class="btn-group">
                                        <form action="<?php echo e(route('diklat.delete')); ?>" method="post">
                                            <a href="<?php echo e(route('diklat.edit',$res->id)); ?>" class="btn btn-default btn-icon-notika" title="Edit">
                                                <i class="notika-icon notika-edit"></i>
                                            </a> 
                                            <?php echo csrf_field(); ?>
                                            <?php if($res->status != '1'): ?>
                                            <input type="hidden" value="<?php echo e($res->id); ?>" name="id">
                                            <button type="submit" onclick="return confirm('Anda yakin?')" 
                                                class="btn btn-default btn-icon-notika">
                                                <i class="notika-icon notika-close"></i>
                                            </button>
                                            <?php endif; ?> 
                                            <a href="<?php echo e(route('materi.all')); ?><?php echo e($res->status!='1' ? '?id_diklat='.$res->id : ''); ?>" class="btn btn-default btn-icon-notika" title="Daftar Materi">
                                                <i class="notika-icon notika-next"></i>
                                            </a>
                                        </form>
                                    </div>  
                                    </td>
                                </tr>                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                   
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Nama Diklat</th>
                                    <th>Kota</th>
                                    <th>Mulai</th>
                                    <th>Selesai</th>
                                    <th>Status</th>
                                    <th>Opsi</th>                                    
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('#tabel-diklat').DataTable( {
            "order": [[ 4, "asc" ]]
        } );
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/home.blade.php ENDPATH**/ ?>