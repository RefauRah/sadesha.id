
<?php $__env->startSection('content'); ?>
<div class="form-example-area" style="margin-top:30px">
    <div class="container">
        <div class="row">
            <form action="<?php echo e(route('peserta.dataDiriUpdate')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-sm-12">
                <div class="form-example-wrap">
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Nama Peserta</label>
                            <div class="nk-int-st">
                                <input type="text" name="nama_peserta" class="form-control input-sm" value="<?php echo e($peserta != null ? $peserta->nama_peserta: ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Email</label>
                            <div class="nk-int-st">
                                <input type="text" name="email" class="form-control input-sm" value="<?php echo e($peserta != null ? $peserta->email: ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="datepicker-int datepicker-restyle  mg-t-15">
                        <div class="form-group nk-datapk-ctm form-elet-mg" id="data_1">
                            <label>Tanggal Lahir</label>
                            <div class="input-group date nk-int-st">
                                <span class="input-group-addon"></span>
                                <input type="text" name="tgl_lahir" class="form-control" value="<?php echo e($peserta != null ? date('m/d/Y', strtotime($peserta->tgl_lahir)) : date('m/d/1995')); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>Alamat</label>
                            <div class="nk-int-st">
                                <textarea name="alamat" class="form-control"><?php echo e($peserta != null ? $peserta->alamat : ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int">
                        <div class="form-group">
                            <label>No. HP</label>
                            <div class="nk-int-st">
                                <input type="text" name="no_hp" class="form-control input-sm" value="<?php echo e($peserta != null ? $peserta->no_hp : ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-example-int mg-t-15">
                        <div class="form-group">
                            <label>Agama</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select name="agama" class="selectpicker" required>
                                <?php if($peserta!=null): ?>
                                    <option <?php echo e($peserta->agama == 'ISLAM' ? 'selected' : ''); ?> value="ISLAM">Islam</option>
                                    <option <?php echo e($peserta->agama == 'KRISTEN' ? 'selected' : ''); ?> value="KRISTEN">Kristen</option>
                                <?php else: ?> 
                                    <option value="ISLAM">Islam</option>
                                    <option value="KRISTEN">Kristen</option>
                                <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>  
                    <div class="form-example-int mg-t-15">
                        <div class="form-group">
                            <label>Status Peserta</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select name="status" class="selectpicker" required>
                                <?php if($peserta!=null): ?>
                                    <option <?php echo e($peserta->status == 'MAHASISWA' ? 'selected' : ''); ?> value="MAHASISWA">MAHASISWA</option>
                                    <option <?php echo e($peserta->status == 'PELAJAR' ? 'selected' : ''); ?> value="PELAJAR">PELAJAR</option>
                                <?php else: ?>
                                    <option value="MAHASISWA">MAHASISWA</option>
                                    <option value="PELAJAR">PELAJAR</option>
                                <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>  
                    <input type="hidden" value="<?php echo e(isset($peserta->id) ? '1' : '0'); ?>" name="is_edit">
                    <button type="submit" class="btn btn-success notika-btn-success">Submit</button>
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger notika-btn-success">Back</a>
                </div>
            </div>
            </form>
        </div>           
    </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH O:\Projects\absen\resources\views/peserta/edit.blade.php ENDPATH**/ ?>