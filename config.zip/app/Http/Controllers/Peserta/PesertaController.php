<?php

namespace App\Http\Controllers\Peserta;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use App\Model\Peserta;
use App\Model\Diklat;

class PesertaController extends Controller{

    public function profile(){
        $peserta = $this->getMe(); 
        $data = [
            'title' => 'Detail Profil - ',
            'breadcrumb' => 'Peserta / Profile',
            'peserta' => $peserta,
            'pendidikan' => [],
            'kerja' => [],
            'organisasi' => [],
            'verified' => false
        ];
        return view('peserta.profile', $data);        
    }

    public function edit(){  
        $data = [
            'title' => 'Edit Profil - ',
            'breadcrumb' => 'Peserta / Data Diri',
            'peserta' => $this->getMe()
            // 'peserta' => $peserta
        ];      
        return view('peserta.edit',$data);
    }

    public function update(Request $req){
        $req->validate([
            'nama_peserta' => 'required',
            'tgl_lahir' => 'required',
            'agama' => 'required',
            'status' => 'required',
            'alamat' => 'required',
            'no_hp' => 'required',
            'email' => 'required',
            'is_edit' => 'required'
        ]);
        
        $current = $this->getCurrent();
        try{ 
            $peserta = new Peserta();
            if($req['is_edit'] == '1'){
                $peserta = $this->getMe();
            }
            $peserta->nama_peserta = $req['nama_peserta'];
            $peserta->tgl_lahir = date('Y-m-d', strtotime($req['tgl_lahir']));
            $peserta->agama = $req['agama'];
            $peserta->status = $req['status'];
            $peserta->alamat = $req['alamat'];
            $peserta->no_hp = $req['no_hp'];
            $peserta->email = $req['email'];
            $peserta->no_peserta = '0';

            if($req['is_edit'] != '1'){
                $peserta->id_user = auth()->user()->id;
                $peserta->id_diklat = $current->id;
                $peserta->is_verified = 0;
            }
            $peserta->save();
        } catch (\Exception $e){
            die([$e]);
        }
        return redirect(route('peserta.dataDiri'));
    }

    public function addPengalamanKerja(Request $req){
        $validator = Validator::make($request->all(), [
            // riwayat pendidikan
            'id_peserta' => 'required',
            'pengalaman_kerja' => 'required|array',
            'pengalaman_kerja.*.nama_instansi' => 'required',
            'pengalaman_kerja.*.jabatan' => 'required',
            'pengalaman_kerja.*.tgl_mulai' => 'required',
            'pengalaman_kerja.*.tgl_selesai' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect('404');
        }

        try{
            $peserta = Peserta::findOrFail($req['id_peserta']);
            foreach($req['pengalaman_kerja'] as $kerja){
                $peserta->kerja()->create([
                    'nama_instansi' => $kerja['nama_instansi'],
                    'jabatan' => $kerja['jabatan'],
                    'tgl_mulai' => $kerja['tgl_mulai'],
                    'tgl_selesai' => $kerja['tgl_selesai']
                ]);
            }
        }catch(\Exception $e){
            return redirect('/');
        }
    }

    public function addPengalamanOrganisasi(Request $req){
        $validator = Validator::make($request->all(), [
            // riwayat pendidikan
            'id_peserta' => 'required',
            'pengalaman_organisasi' => 'required|array',
            'pengalaman_kerja.*.nama_organisasi' => 'required',
            'pengalaman_kerja.*.jabatan' => 'required',
            'pengalaman_kerja.*.tahun' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect('404');
        }

        try{
            $peserta = Peserta::findOrFail($req['id_peserta']);
            foreach($req['pengalaman_organisasi'] as $organisasi){
                $peserta->kerja()->create([
                    'nama_organisasi' => $organisasi['nama_organisasi'],
                    'jabatan' => $organisasi['jabatan'],
                    'tahun' => $organisasi['tahun']
                ]);
            }
        }catch(\Exception $e){
            return redirect('/');
        }
    }


    private function getCurrent(){
        $currentDiklat = Diklat::where('status','1')->first();
        return $currentDiklat;
    }

    private function getMe(){
        return auth()->user()->peserta;
    }

}
