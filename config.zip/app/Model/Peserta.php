<?php

namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class Peserta extends Model
{
    protected $table = 'peserta';
    protected $primaryKey = 'id';
    protected $hidden = ['deleted_at', 'created_at'];

    protected $fillable = [
        'id_diklat',
        'id_user',
        'no_peserta',
        'nama_peserta',
        'tgl_lahir',
        'agama',
        'status',
        'alamat',
        'no_hp',
        'email',
        'is_verified',
    ];

    public function diklat()
    {
        return $this->belongsTo('App\Model\Diklat', 'id_diklat');
    }

    public function pendidikan()
    {
        return $this->hasMany('App\Model\RiwayatPendidikan', 'id_peserta');
    }

    public function kerja()
    {
        return $this->hasMany('App\Model\PengalamanKerja', 'id_peserta');
    }

    public function organisasi()
    {
        return $this->hasMany('App\Model\PengalamanOrganisasi', 'id_peserta');
    }

    public function absensi()
    {
        return $this->hasMany('App\Model\Absensi', 'id_peserta');
    }
}
